DI='[{"PtName":"P1.V.Status","PtDesc":"P1 Valve Status","PtVal":"0","PtCurState":"Normal","PtState0":"Normal","PtState1":"Alarm","LastTime":"01 JAN 2017"},'+
     '{"PtName":"P2.V.Status","PtDesc":"P2 Valve Status","PtVal":"0","PtCurState":"Normal","PtState0":"Normal","PtState1":"Alarm","LastTime":"01 JAN 2017"},'+
     '{"PtName":"P3.V.Status","PtDesc":"P3 Valve Status","PtVal":"0","PtCurState":"Normal","PtState0":"Normal","PtState1":"Alarm","LastTime":"01 JAN 2017"},'+
     '{"PtName":"P4.V.Status","PtDesc":"P4 Valve Status","PtVal":"0","PtCurState":"Normal","PtState0":"Normal","PtState1":"Alarm","LastTime":"01 JAN 2017"},'+
     '{"PtName":"P5.V.Status","PtDesc":"P5 Valve Status","PtVal":"0","PtCurState":"Normal","PtState0":"Normal","PtState1":"Alarm","LastTime":"01 JAN 2017"},'+
     '{"PtName":"P6.V.Status","PtDesc":"P6 Valve Status","PtVal":"0","PtCurState":"Normal","PtState0":"Normal","PtState1":"Alarm","LastTime":"01 JAN 2017"},'+
     '{"PtName":"P11.V.Status","PtDesc":"P7 Valve Status","PtVal":"0","PtCurState":"Normal","PtState0":"Normal","PtState1":"Alarm","LastTime":"01 JAN 2017"},'+
     '{"PtName":"P7.V.Status","PtDesc":"P7 Value Status","PtVal":"0","PtCurState":"Normal","PtState0":"Normal","PtState1":"Alarm","LastTime":"01 JAN 2017"}]';
module.exports.DI=DI;
AI='[{"PtName":"SH.Temp","PtDesc":"P1 Gas Tempurature","PtVal":0,"Unit":"C"},'+
     '{"PtName":"SH.V","PtDesc":"P1 Gas Pressure","PtVal":0,"Unit":"V"},'+
     '{"PtName":"SH.I","PtVal":0,"Unit":"A"},'+
     '{"PtName":"SH.P","PtDesc":"P2 Gas Tempurature","PtVal":0,"Unit":"kW"},'+
     '{"PtName":"SH.E","PtDesc":"P2 Gas Pressure","PtVal":0,"Unit":"kWh"},'+
     '{"PtName":"SH.H","PtVal":0,"Unit":"%"}]';
module.exports.AI=AI;
           
